// ---------------------------------------------------------------------------
// Copyright (c) 2008-2011, Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This work, unless otherwise expressly stated, is licensed under a
// Creative Commons Attribution-ShareAlike 2.5.
// The full license document is available from
// http://creativecommons.org/licenses/by-sa/2.5/legalcode .
// ---------------------------------------------------------------------------

#include <QtGui/QApplication>
#include "qmlapplicationviewer.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    QmlApplicationViewer viewer;
    viewer.setMainQmlFile(QLatin1String("qml/TodoList/main.qml"));
    viewer.showExpanded();

    return app.exec();
}
