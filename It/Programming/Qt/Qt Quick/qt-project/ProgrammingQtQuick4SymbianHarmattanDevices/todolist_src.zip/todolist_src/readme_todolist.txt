Dear Qt and Qt Quick developer,

thank you for your interest to download the archive with the source code of TodoList.

This zip archive is a part of the "Programming with Qt Quick for Symbian and MeeGo Harmattan Devices", version 1.1.

You can find this guide under the following URL:

http://qt.nokia.com/learning/guides

We strongly advise downloading and reading the guide, since this will save your time and make the use of source code much easier.

Have fun and good luck in your projects!

--

Qt Learning Team
http://qt.nokia.com/learning/

